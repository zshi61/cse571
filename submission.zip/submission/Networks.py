import torch
import torch.nn as nn
from Data_Loaders import Data_Loaders


class Action_Conditioned_FF(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        # Initialize the parent class
        super(Action_Conditioned_FF, self).__init__()

        # Define your network's architecture
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)

    def forward(self, input):
        x = self.relu(self.fc1(input))
        x = self.dropout(x)  # Apply dropout
        x = self.relu(self.fc2(x))
        output = self.fc3(x)
        return output
        #print(output)

    def evaluate(self, model, test_loader, loss_function):
        # Set the model to evaluation mode
        model.eval()
        total_loss = 0.0
        with torch.no_grad():  # No gradients needed during evaluation
            for batch in test_loader:
                inputs = batch['input']
                labels = batch['label']
                outputs = model(inputs)  # Get model predictions
                loss = loss_function(outputs, labels)  # Compute loss
                total_loss += loss.item()  # Accumulate loss

        average_loss = total_loss / len(test_loader)  # Average loss over batches
        print(f'average loss is {average_loss}')
        return average_loss


def main():
    batch_size = 16
    data_loaders = Data_Loaders(batch_size)

    # Initialize model
    input_size = data_loaders.nav_dataset.data.shape[1] - 1  # input size = number of features
    hidden_size = 64  # Number of hidden units
    output_size = 1  # Define output size (e.g., regression task)
    model = Action_Conditioned_FF(input_size, hidden_size, output_size)

    # Define loss function and optimizer
    loss_function = nn.MSELoss()  # Mean Squared Error for regression tasks
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)  # Adam optimizer with learning rate

    # Training loop
    no_epochs = 10
    for epoch_i in range(no_epochs):
        model.train()  # Set the model to training mode
        epoch_loss = 0.0  # Initialize epoch loss

        # Iterate through the training data
        for idx, sample in enumerate(data_loaders.train_loader):
            inputs = sample['input']  # Get inputs
            labels = sample['label']  # Get corresponding labels
            optimizer.zero_grad() # Zero the gradients

            # Forward pass
            outputs = model(inputs)  # Get model outputs
            loss = loss_function(outputs, labels)  # Calculate loss

            # Backpropagation
            loss.backward()
            optimizer.step()  # Update weights

            epoch_loss += loss.item()  # Accumulate loss for the epoch

        # Calculate average loss for the epoch
        avg_epoch_loss = epoch_loss / len(data_loaders.train_loader)
        print(f'Epoch [{epoch_i + 1}/{no_epochs}], Loss: {avg_epoch_loss:.4f}')

        # Evaluate model after each epoch
        model.evaluate(model, data_loaders.test_loader, loss_function)


if __name__ == '__main__':
    main()
